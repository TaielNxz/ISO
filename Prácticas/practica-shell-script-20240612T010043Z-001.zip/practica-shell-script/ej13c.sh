#!/bin/bash

archivo=$1

if [ -e $archivo ]; then
	echo "El archivo $archivo SI existe"
	if [ -f $archivo ]; then echo "es un archivo"; fi
	if [ -d $archivo ]; then echo "es un directorio"; fi
	exit
fi

echo "El archivo $archivo NO existe"
echo "Creando directorio $archivo"
mkdir $archivo

