
#!/bin/bash

apellido="pepe"

echo ${apellido}
