# 18) Crear un script que verifique cada 10 segundos si un usuario se ha loqueado en el sistema 
#     (el nombre del usuario será pasado por parámetro). 
#     Cuando el usuario finalmente se loguee, el programa deberá mostrar el mensaje ”Usuario XXX logueado en el sistema” y salir.

#!/bin/bash


if [ $# -ne 1 ]; then
    echo "solo se puede ingresar un parametro"
    exit 1
fi

usuario=$( cat /etc/passwd | cut -d : -f1 | grep -w $1 | wc -l )

if [ $usuario -ne 1 ]; then
    echo "el usuario no existe"
    exit 2
fi


while [ $( users | grep -w $1 | wc -l ) -eq 0 ]; do
    echo "esperando..."
    sleep 10
done

echo "Usuario $1 logueado en el sistema"
exit 0
