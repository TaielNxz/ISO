#!/bin/bash
# 4) Parametrización: 
#    ¿Cómo se acceden a los parámetros enviados al script al momento de su invocación? 
#    ¿Qué información contienen las variables $#, $*, $? y $HOME dentro de un script?

echo "(\$#) cantidad de parametros ingregados: $#"
echo "(\$*) Lista de parametros: $*"
echo "(\$?) Valor de retorno del ultimo comando ejecutado ( 0 --> exito , 1..255 ---> error ):  $?"
echo "(\$0) Nombre del script: $0"
echo "(\$1) El primer parametro es: $1"
echo "(\$2) El segundo parametro es: $2"
echo "(\$3) EL tercer parametro es: $3"

