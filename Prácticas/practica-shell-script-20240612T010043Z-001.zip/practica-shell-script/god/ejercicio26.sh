# 26) Escriba un script que reciba una cantidad desconocida de parámetros al momento de su invocación (debe validar que al menos se reciba uno). 
#     Cada parámetro representa la ruta absoluta de un archivo o directorio en el sistema. 
#     El script deberá iterar por todos los parámetros recibidos, y solo para aquellos parámetros que se encuentren en posiciones impares 
#     (el primero, el tercero, el q_______
#     verificar si el archivo o directorio existen en el sistema, imprimiendo en pantalla que tipo de objeto es (archivo o directorio). 
#     Además, deberá informar la cantidad de archivos o directorios inexistentes en el sistema.


#!/bin/bash

if [ $# -le 1 ]; then
    echo "se requiere minimo un parametro"
    exit 1
fi

pos=0
noExiste=0

for i in $* ;do

    let pos++

    if [ $(expr $pos % 2) -ne 0 ]; then
        
	# verificar si existe
	if ! [ -e $i ]; then
	    echo "$pos : el arcivo no existe"
	    let noExiste++
	    continue
        fi

	# verificar si es un Directorio
	if [ -d $i ]; then
	    echo "$pos : es un directorio"
	fi;

	# verificar si es un Archivo
   	if [ -f $i ]; then
	    echo "$pos : es un archivo"
	fi;

    else
	continue
    fi 

done

echo "Cantidad de archivos inexistentes: $noExiste"
