# 23) Implemente un script que recorra un arreglo compuesto por números e imprima en pantalla sólo los números pares 
#     y que cuente sólo los números impares y los informe en pantalla al finalizar el recorrido


#!/bin/bash

if [ $# -ne 0 ]; then
    echo "QUE HACES?, no pases parametros"
    exit 1
fi


numeros=(2 5 3 6 7 2)
impares=0

for i in ${numeros[*]}; do

    if [ $(expr $i % 2) -eq 0 ]; then
	# echo "$i es par";
	echo $i
    else 
	# echo "$i es impar";
	impares=$(expr $impares + 1)
    fi
done

echo "Cantidad de impares: $impares"
exit 0

