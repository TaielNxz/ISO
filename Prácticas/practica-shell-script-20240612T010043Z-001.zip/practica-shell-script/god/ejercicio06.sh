# 6) El comando 'expr' permite la evaluación de expresiones. 
#    Su sintaxis es: 'expr arg1 op arg2', 
#    donde 'arg1' y 'arg2' representan argumentos y 'op' la operación de la expresión. 
#    Investigar que tipo de operaciones se pueden utilizar


#!/bin/bash

echo "arg1=10 arg2=5"
echo
echo "Operadores aritmeticos:"
echo "suma: $( expr 10 + 5 )"
echo "resta: $( expr 10 - 5 )"
echo "multiplicacion: $( expr 10 \* 5 )"
echo "division: $( expr 10 / 5 )"
echo "resto: $( expr 10 % 5 )" 
echo
echo "Operadores relacionales ( 0 --> false ; 1 --> true ):"
echo "igual: $( expr 10 = 5 )" 
echo "distinto: $( expr 10 != 5 )" 
echo "mayor que: $( expr 10 \> 5 )" 
echo "mayorr o igual que: $( expr 10 \>= 5 )" 
echo "menor que: $( expr 10 \< 5 )" 
echo "menor o igual que: $( expr 10 \<= 5 )" 
