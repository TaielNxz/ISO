# 7) El comando “test expresión” permite evaluar expresiones y generar un valor de retorno, true o false. 
#    Este comando puede ser reemplazado por el uso de corchetes de la siguiente manera [ expresión ]. 
#    Investigar que tipo de expresiones pueden ser usadas con el comando test. 
#    Tenga en cuenta operaciones para: evaluación de archivos, evaluación de cadenas de caracteres y evaluaciones numéricas.



#!/bin/bash

# ======================================================================
# Evaluación de archivos
# ======================================================================

# Comprobación de existencia de archivo:
test -f archivo.txt
Este comando devolverá un valor de salida de 0 
si el archivo existe y es un archivo regular.

# Comprobación de tamaño de archivo:
test -s archivo.txt
Este comando devolverá un valor de salida de 0 
si el archivo existe y tiene un tamaño mayor que 0.

# Comprobación de contenido de archivo:
test -z archivo.txt
Este comando devolverá un valor de salida de 0 
si el archivo existe y está vacío.

# Comprobación de acceso a archivo:
test -r archivo.txt
Este comando devolverá un valor de salida de 0 
si el archivo existe y tiene permisos de lectura.

# Comprobación de escritura en archivo:
test -w archivo.txt
Este comando devolverá un valor de salida de 0 
si el archivo existe y tiene permisos de escritura.

# ======================================================================
# Evaluación de cadenas de caracteres
# ======================================================================

# Comprobación de igualdad de cadenas:
test "Hola, mundo" = "Hola, mundo"
Este comando devolverá un valor de salida de 0 
si las dos cadenas son iguales.
    
# Comprobación de desigualdad de cadenas:
test "Hola, mundo" != "Hola, mundo"
Este comando devolverá un valor de salida de 0 
si las dos cadenas son diferentes.

# Comprobación de longitud de cadena:
test "${#cadena}" -gt 10
Este comando devolverá un valor de salida de 0 
si la longitud de la cadena es mayor que 10.

# Comprobación de existencia de caracteres en una cadena:
test "Hola, mundo" =~ "a"
Este comando devolverá un valor de salida de 0 
si la cadena contiene el carácter "a".

# Comprobación de ausencia de caracteres en una cadena:
test "Hola, mundo" !~ "z"
Este comando devolverá un valor de salida de 0 
si la cadena no contiene el carácter "z".

# ======================================================================
# Evaluaciones numéricas
# ======================================================================

# Comprobación de igualdad de números:
test 10 = 10
Este comando devolverá un valor de salida de 0 
si los dos números son iguales.

# Comprobación de desigualdad de números:
test 10 != 11
Este comando devolverá un valor de salida de 0 
si los dos números son diferentes.

# Comprobación de mayor que:
test 10 > 5
Este comando devolverá un valor de salida de 0 
si el primer número es mayor que el segundo.

# Comprobación de menor que:
test 10 < 11
Este comando devolverá un valor de salida de 0 
si el primer número es menor que el segundo.

# Comprobación de mayor o igual que:
test 10 >= 10
Este comando devolverá un valor de salida de 0 
si el primer número es mayor 
