# 21) Dentro del mismo script y utilizando las funciones implementadas

# Agregue 10 elementos a la pila.
# Saque 3 de ellos.
# Imprima la longitud de la cola.
# Luego imprima la totalidad de los elementos que en ella se encuentan

#!/bin/bash
pila=()

push (){
  pila+=($1)
}

pop (){
  unset pila[${#pila[@]}-1]
}

lenght (){
  echo ${#pila[*]}
}

print(){
  echo ${pila[*]}
}


push 2
push 4
push 6
push 8
push 10
push 12
push 14
push 16
push 18
push 20

pop 
pop
pop

echo "Longitud de la cola: " $(lenght)
echo "Elementos de la cola: " $(print)
