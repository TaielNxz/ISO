# 29) Ejercicio
#     Implemente un script que agregue a un arreglo todos los archivos del directorio /home cuya terminación sea .doc. 
#     Adicionalmente, implemente las siguientes funciones que le permitan acceder a la estructura creada:
#    
#     - verArchivo <nombre_de_archivo>: Imprime el archivo en pantalla si el mismo se encuentra en el arreglo. 
#       Caso contrario imprime el mensaje de error “Archivo no encontrado” y devuelve como valor de retorno 5
#     - cantidadArchivos: Imprime la cantidad de archivos del /home con terminación .doc
#     - borrarArchivo <nombre_de_archivo>: Consulta al usuario si quiere eliminar el archivo lógicamente. 
#       Si el usuario responde Si, elimina el elemento solo del arreglo. 
#       Si el usuario responde No, elimina el archivo del arreglo y también del FileSystem. 
#       Debe validar que el archivo exista en el arreglo. 
#       En caso de no existir, imprime el mensaje de error “Archivo no encontrado” y devuelve como valor de retorno 10

#!/bin/bash

verArchivo() {
    # verificar que solo se ingresara un parametro
    if [ $# -ne 1 ]; then
    	echo "1 solo parametro pa"
    else	
        existe=false;

	# recorro el arreglo de archivos
        for archivo in ${arreglo[*]}; do

            # si uno de los archivos coinside con el parametro ingresado existe=true
    	    if [ $archivo = $1 ]; then 
                existe=true
                break
    	    fi
        done

        # si se encontro retorna 5
        if [ $existe = "false" ]; then
    	    echo "archivo no encontrado"
    	    return 5

	# si el archivo se encontro lo imprime en pantalla
        else
            echo "El archivo ' $1 ' SI existe, contenido:"
    	    echo $(cat $HOME/$1)
        fi
    fi
}


cantidadArchivos() {
    echo "Cantidad de archivos: ${#arreglo[*]}"
}


borrarArchivo() {
    if ! [ -e "$HOME/$1" ]; then
        echo "Archivo no encontrado"
        return 10
    else
        echo "Desea borrar el archivo ' $1 ' de manera logica?"
	select opcion in "SI" "NO" "SALIR"  
    	do
	    case $opcion in
	        "SI") unset "$archivos_doc[$1]"; break;;
	        "NO") rm "$HOME/$1"; break ;;
	        "SALIR") break;;
	    esac
        done
    fi
}







# crear el arreglo
arreglo=()

# buscar y guardar los archivos que terminen en ".doc" en la variable "archivos"
archivos=$( ls $HOME | grep '\.doc' )

# guardar los archivos en el arreglo
for archivo in $archivos; do
    arreglo+=($archivo)
done


verArchivo 1.doc
cantidadArchivos
borrarArchivo 1.doc
