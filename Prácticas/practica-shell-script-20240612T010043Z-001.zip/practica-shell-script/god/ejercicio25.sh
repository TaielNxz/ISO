# 25) Realice un script que agregue en un arreglo todos los nombres de los usuarios del sistema pertenecientes al grupo “users”. 
#     Adicionalmente el script puede recibir como parametro:

#   “-b n”: Retorna el elemento de la posición n del arreglo si el mismo existe. Caso contrario, un mensaje de error.
#   “-l”: Devuelve la longitud del arreglo
#   “-i”: Imprime todos los elementos del arreglo en pantalla

#!/bin/bash

if [ $# -ne 1 ] && [ $# -ne 2 ]; then 
    echo "Parametros Invalidos"
    exit 1
fi

usuarios=$(cat /etc/group | grep -w users | cut -d : -f4 | tr "," " " )
arreglo=($usuarios)


case $1 in 
    -b) if [ $2 -lt ${#usuarios[*]} ]; then 
	    echo "${usuarios[$2]}" 
        else 
            echo "te fuiste un poco al choto"
            exit 2
	fi;;
    -l) echo "Cantidad de usuarios: ${#usuarios}" ;;
    -i) echo "Nombres de los usuarios: ${usuarios[*]}";;
esac
exit 0
