# 30) Realice un script que mueva todos los programas del directorio actual (archivos ejecutables) 
#     hacia el subdirectorio “bin” del directorio HOME del usuario actualmente logueado. 
#     El script debe imprimir en pantalla los nombres de los que mueve, e indicar cuántos ha movido, o que no ha movido ninguno. 
#     Si el directorio “bin” no existe,deberá ser creado.

#!/bin/bash

bin="$HOME/bin"

if ! [ -e $bin ]; then 
    mkdir $bin
    echo "directorio 'bin' creado"
fi

movidos=0
archivos=$(ls | grep "\.exe")

for archivo in $archivos; do

    mv $archivo $bin
    if [ $? -eq 0 ]; then
	echo "Se movio el archivo: $archivo"
        let movidos++
    fi

done

if [ $movidos -ne 0 ]; then
    echo "Se movieron $movidos archivos"
else
    echo "No se movio ningun archivo"
fi

exit 0
