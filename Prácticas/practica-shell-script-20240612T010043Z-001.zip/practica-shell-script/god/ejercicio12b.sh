# 12) Evaluacion de expresiones:

# (a) Realizar un script que le solicite al usuario 2 números, los lea de la entrada Standard
#    de imprima la multiplicación, suma, resta y cual es el mayor de los números leídos.

# (b) Modificar el script creado en el inciso anterior para que los números sean recibidos como parámetros. 
#     El script debe controlar que los dos parámetros sean enviados.

# (c) Realizar una calculadora que ejecute las 4 operaciones básicas: +, - ,*, %. 
#     Esta calculadora debe funcionar recibiendo la operación y los números como parámetros

#!/bin/bash

if [ $# -ne 2 ]; then
    echo "No se ingresaron 2 parametros"
    exit 1
fi

multiplicacion=$(($1 * $2))
suma=$(($1 + $2))
resta=$(($1 - $2))

echo "$1 * $2 = " $multiplicacion
echo "$1 + $2 =" $suma
echo "$1 - $2 =" $resta





