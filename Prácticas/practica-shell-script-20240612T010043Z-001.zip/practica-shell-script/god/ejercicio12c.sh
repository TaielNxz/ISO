# 12) Evaluacion de expresiones:

# (a) Realizar un script que le solicite al usuario 2 números, los lea de la entrada Standard
#    de imprima la multiplicación, suma, resta y cual es el mayor de los números leídos.

# (b) Modificar el script creado en el inciso anterior para que los números sean recibidos como parámetros. 
#     El script debe controlar que los dos parámetros sean enviados.

# (c) Realizar una calculadora que ejecute las 4 operaciones básicas: +, - ,*, %. 
#     Esta calculadora debe funcionar recibiendo la operación y los números como parámetros

#!/bin/bash

if [ $# -ne 2 ]; then
    echo "Se deben ingresar 2 parametros"
    exit 1
fi

# '^'  --> el parametro debe ser un digito
# '+$' --> el parametro esta compuesto por digitos y termina con un digito
if ! [[ $1 =~ ^[1-9]+$ ]] || ! [[ $2 =~ ^[1-9]+$ ]]; then
    echo "no capo"
    exit 1
fi

select op in "sumar" "restar" "multiplicar" "resto"
do
   case $op in
      "sumar")       echo "$1 + $2 = $(($1 * $2))";;
      "restar")      echo "$1 - $2 = $(($1 + $2))";;
      "multiplicar") echo "$1 * $2 = $(($1 * $2))";;
      "resto")       echo "$1 % $2 = $(($1 % $2))";;
      *) exit ;;
   esac  
done




