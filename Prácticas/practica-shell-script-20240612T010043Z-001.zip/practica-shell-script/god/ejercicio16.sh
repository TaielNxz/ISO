# 16) Realizar un script que reciba como parámetro una extensión y haga un reporte con 2 columnas, 
#     el nombre de usuario y la cantidad de archivos que posee con esa extensión.
#     Se debe guardar el resultado en un archivo llamado reporte.txt


#!/bin/bash

if [ $# -ne 1 ]; then
    echo "se debe ingresar un solo parametro"
    exit 1
fi


# Obtiene la extensión del archivo
extension=$1

# Obtiene a los usuarios
usuarios=$(cat /etc/passwd | cut -d: -f1)

# Busca todos los archivos con la extensión especificada
archivos=$(find . -type f -name "*.$extension")


# Cuenta la cantidad de archivos para cada usuario
for archivo in $archivos; do

     # Obtiene el nombre de usuario del archivo
     usuario=$(stat -c "%u" $archivo)

     # Cuenta la cantidad de archivos para el usuario actual
     contador=$(find . -name "*.$extension" -user $usuario | wc -l)

     # Agrega una nueva línea al archivo de salida
     echo "USUARIO: $usuario | CONTADOR $contador" >> reporte.txt
done
exit 0
