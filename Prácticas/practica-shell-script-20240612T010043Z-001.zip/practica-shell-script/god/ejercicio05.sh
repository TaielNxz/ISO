# 5) ¿Cual es la funcionalidad de comando exit?
#    ¿Qué valores recibe como parámetro y cual es su significado?

# exit 0 --> el script se ejecuto de forma exitosa

# cualquier otro valor indica un codigo de error:
# exit 1 --> el script fallo
# exit 2 --> el script se interrumpio por el usuario
# exit 3 --> el script se interrumpio por un error interno




