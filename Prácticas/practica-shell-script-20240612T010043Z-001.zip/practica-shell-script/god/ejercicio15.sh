# 15) Comando cut: 
# El comando cut nos permite procesar la líneas de la entrada que reciba 
# (archivo, entrada estándar, resultado de otro comando, etc) 
# y cortar columnas o campos, siendo posible indicar cual es el delimitador de las mismas. 
# Investigue los parámetros que puede recibir este comando y cite ejemplos de uso.

