# 28) Realice un script que reciba como parámetro el nombre de un directorio. 
#     Deberá validar que el mismo exista y de no existir causar la terminación del script con código de error 4. 
#     Si el directorio existe deberá contar por separado la cantidad de archivos que en él se encuentran para los cuales 
#     el usuario que ejecuta el script tiene permiso de lectura y escritura, e informar dichos valores en pantalla. 
#     En caso de encontrar subdirectorios, no deberán procesarse, y tampoco deberán ser tenidos en cuenta para la suma a informar.

#!/bin/bash


if [ $# -ne 1 ]; then
    echo "se requiere un solo parametro"
    exit 1
fi

if ! [ -d $1 ] ; then 
    echo "el directorio $1 no existe"
    exit 4
fi


archivos=$(ls $1)
echo $archivos

cant=0
for i in $archivos; do
    if [ -f $1/$i ] && [ -w $1/$i ] && [ -r $1/$i ]; then
        let cant++
    fi
done

echo "Cantidad: $cant"
exit 0
