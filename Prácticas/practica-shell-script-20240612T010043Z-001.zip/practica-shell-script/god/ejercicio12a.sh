# 12) Evaluacion de expresiones:

# (a) Realizar un script que le solicite al usuario 2 números, los lea de la entrada Standard
#    de imprima la multiplicación, suma, resta y cual es el mayor de los números leídos.

# (b) Modificar el script creado en el inciso anterior para que los números sean recibidos como parámetros. 
#     El script debe controlar que los dos parámetros sean enviados.

# (c) Realizar una calculadora que ejecute las 4 operaciones básicas: +, - ,*, %. 
#     Esta calculadora debe funcionar recibiendo la operación y los números como parámetros

#!/bin/bash

read -p "Ingrese 2 numeros: " num1 num2

multiplicacion=$((num1 * num2))
suma=$((num1 + num2))
resta=$((num1 - num2))

echo "$num1 * $num2 = " $multiplicacion
echo "$num1 + $num2 =" $suma
echo "$num1 - $num2 =" $resta
