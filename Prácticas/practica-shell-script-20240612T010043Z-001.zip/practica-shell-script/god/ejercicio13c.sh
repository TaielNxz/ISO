# 13) Uso de las estructuras de control:

# (a) Realizar un script que visualice por pantalla los números del 1 al 100 así como sus cuadrados. 

# (b) Crear un script que muestre 3 opciones al usuario: Listar, DondeEstoy y QuienEsta. Según la opción elegida se le debe mostrar:
#    Listar: lista el contenido del directoria actual.
#    DondeEstoy: muestra el directorio donde me encuentro ubicado.
#    QuienEsta: muestra los usuarios conectados al sistema.

# (c) Crear un script que reciba como parámetro el nombre de un archivo e informe si el mismo existe o no, 
#     y en caso afirmativo indique si es un directorio o un archivo. 
#     En caso de que no exista el archivo/directorio cree un directorio con el nombre recibido como parámetro
#


#!/bin/bash

if [ $# -ne 1 ]; then
    echo "que haces?"
    exit 1
fi

nombre=$1

# preguntar si existe al archivo
if [ -e $1 ]; then

    # preguntar si es un archivo
    if [ -f $1 ]; then echo "es un archivo"; fi

    # preguntar si es un directorio
    if [ -d $1 ]; then echo "es un directorio"; fi

    exit;
fi

mkdir $1
echo "directorio $1 creado"
exit 0
