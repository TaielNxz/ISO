# 2) Investigar la funcionalidad de los comandos 'echo' y 'read'
echo "Ingresar Algo:"
read var
echo "Ingresaste:"
echo $var


