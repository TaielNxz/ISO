#!/bin/bash

select opcion in "Opción 1" "Opción 2" "Opción 3"; do
  case $opcion in
    "Opción 1")
      echo "Has seleccionado la opción 1";;
    "Opción 2")
      echo "Has seleccionado la opción 2";;
    "Opción 3")
      echo "Has seleccionado la opción 3";;
     *)exit;;
  esac
done
