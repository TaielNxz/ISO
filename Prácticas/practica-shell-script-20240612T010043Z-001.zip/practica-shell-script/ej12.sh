#!/bin/bash

read -p "Ingrese dos numeros: " nro1 nro2

echo "$nro1 * $nro2 = $(( $nro1 * $nro2 ))"
echo "$nro1 + $nro2 = $(( $nro1 + $nro2 ))"
echo "$nro1 - $nro2 = $(( $nro1 - $nro2 ))"

if [ $nro1 -gt $nro2 ]; then
  echo "$nro1 > $nro2"
else 
  echo "$nro1 < $nro2"
fi
