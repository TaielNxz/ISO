#!/bin/bash

suma="$(expr 10 + 5)"
resta="$(expr 10 - 5)"
multiplicacion="$(expr 10 \* 5)"
division="$(expr 10 / 5)"
modulo="$(expr 10 % 5)"

echo "sintaxis: expr arg1 op arg2"
echo "arg1= 10"
echo "arg2= 5"
echo
echo "SUMA $suma"
echo "RESTA $resta"
echo "MULTIPLICACION $multiplicacion"
echo "DIVISION $division"
echo "MODULO $modulo"
