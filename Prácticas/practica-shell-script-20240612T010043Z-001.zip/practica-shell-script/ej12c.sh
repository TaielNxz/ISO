#!/bin/bash

# Recibe los datos como parámetros
nro1=$1
operador=$2
nro2=$3

case $operacion in
	"+") resultado=$(( nro1 + nro2 ));;
	"-") resultado=$(( nro1 - nro2 ));;
	"*") resultado=$(( nro1 * nro2 ));;
	"%") resultado=$(( nro1 % nro2 ));;
	*) "operacion no valida";;
esac

# Imprime el resultado
echo "El resultado es $resultado"
