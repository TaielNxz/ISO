# ISO - PARCIAL 2011 - TEMA 1 

# 18) Realice un scrip que agregue a un arreglo los nombres de los archivos del directorio /etc cuya terminacion sea .conf 
#     e implemente las siguientes funciones:
#     - cantidad: Imprime la cantidad de archivos del /etc con terminacion .conf
#     - verArchivos: Imprime los nombres de todos los archivos del /etc con terminacion .conf
#     - existe: Recibe como primer parametro el nombre de un archivo con terminacion .conf e imprime en pantalla si existe en el /etc o no
#     - eliminarL Recibe como primer parametro el nombre de una rchivo con terminacion .conf y como segundo parametro 
#       la cadena Logico o fisico. SI el segundo parametro es logico, solo se borra la entrada en el arreglo, si es fisico borra la
#       entrada en el arreglo y en el FilSystem informando en cada caso la accion realizada


#!/bin/bash

arreglo=()

for archivo in $(ls /etc/ | grep "\.conf" ); do
    arreglo+=($archivo)
done

cantidad() {
    if [ $# -eq 0 ]; then
    	echo "Cantidad de archivos: ${#arreglo[*]}"
    else
        echo "no se deben ingresar parametros"
    fi
}

verArchivos() {
    echo "Nombres de los archivos: "
    echo ${arreglo[*]}
}

existe() {
    if [ -e /etc/$1 ]; then
        echo "el archivo ' $1 ' SI existe"
    else
        echo "el archivo ' $1 ' NO existe"
    fi
}

eliminarL() {

    if [ $# -ne 2 ]; then
       echo "cantidad de parametros invalida"

    elif ! [ -e /etc/$1 ]; then
       echo "no se puede eliminar ' $1 ' porque NO existe"

    elif [ $2 = logico ]; then
       pos=0
       for archivo in ${arreglo[*]}; do
            if [ $archivo = $1 ]; then
                unset arreglo[$pos]
                echo "El archivo ' $1 ' fue borrado del arreglo"
                break
            fi
	    let pos++
       done
    elif [ $2 = fisico ]; then
        rm /etc/$1
        echo "El archivo ' $1 ' fue eliminado del fileSystem"
    else
        echo "instruccion invalida"
    fi
}

cantidad
verArchivos
existe apg.conf
existe hola.conf
eliminarL hola.conf fisico

