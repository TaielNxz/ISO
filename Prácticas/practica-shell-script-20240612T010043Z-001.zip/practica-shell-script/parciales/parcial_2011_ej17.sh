# ISO - PARCIAL 2011 - TEMA 2
#
# 17) Escriba un script que reciba una cantidad desconocida de parametros al momento de su invocacion (debe validar que al menos se reciba uno)
#     Cada parametro repesenta la ruta absoluta de un archivo o directorio en el sistema. El script debe iterar por todos los parametros recibidos,
#     y solo para aquellos parametros que se encuentren en posiciones impares (el primero, el tercero, el quinto),
#     verificar si el archivo o directorio existen en el sistema, imprimiendo en pantalla que tipo de objeto es (archivo o directorio).
#     Ademas debera informar la cantidad de archivos o directorios intexsitentes en el sistema

