#!/bin/bash

for ((i=1; i<=5; i++))
do
  echo $i
done
echo " = = = = = = "
for j in 1 2 3 4 5
do
  echo $j
done
echo " = = = = = = "
for k in {1..10}
do
  echo $k
done
