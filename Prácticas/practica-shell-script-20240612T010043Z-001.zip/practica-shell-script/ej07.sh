#/bin/bash

# Evaluacion de Archivos

if [ -f ej07.sh ]; then echo "el archivo existe"; else echo "el archivo no existe";fi

# Evaluacion de Strings

if [ "Hola" = "alo" ]; then "Igualitos"; else echo "nop";fi

# Evaluacion numerica

if [ 10 = 10 ]; then echo "Son Iguales"; else echo "Son diferentes";fi
