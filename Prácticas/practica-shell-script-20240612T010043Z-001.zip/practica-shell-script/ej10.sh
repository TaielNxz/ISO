#!/bin/bash

# arreglo vacio
vacio=()

# arreglo con valores
numeros=(1 2 3 4)

# leer de teclado y crear arreglo
echo "Ingrese valores para cargar el arreglo"
read -a array 
echo "Todos los elementos: " ${array[*]}
echo "Cantidad de elementos: " ${#array[*]}
