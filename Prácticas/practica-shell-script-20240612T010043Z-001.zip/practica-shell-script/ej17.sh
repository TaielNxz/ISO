#!/bin/bash

# Obtiene la lista de archivos en el directorio actual
archivos=$(ls)

# Recorre la lista de archivos
for archivo in $archivos; do
  # Intercambia minúsculas por mayúsculas
  archivo=$(echo $archivo | tr '[:lower:]' '[:upper:]')

  # Elimina la letra a
  archivo=$(echo $archivo | tr -d 'aA')

  # Imprime el nombre del archivo
  echo $archivo
done
