#!/bin/bash

read -p "Ingrese un caracter: " letra
case $letra in
  [a-z]) echo "Es una minuscula";;
  [A-Z]) echo "Es una mayuscula";;
  [0-9]) echo "Es un numero";;
  *) echo "ES cualquier cosa";;
esac
