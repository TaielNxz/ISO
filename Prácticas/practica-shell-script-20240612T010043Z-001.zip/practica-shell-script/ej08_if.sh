#!/bin/bash

# Ingresar numero por consola
read -p "Ingrese un numero: " numero

# Comprobar si un número es mayor que 10
if [ $numero -gt 10 ]; then
  echo "El número es mayor que 10"
else
  echo "El número es menor o igual que 10"
fi
