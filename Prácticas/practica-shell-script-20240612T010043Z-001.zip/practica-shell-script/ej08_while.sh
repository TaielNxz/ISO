#!/bin/bash

# Imprimir los números del 1 al 10
i=1

while [ $i -le 10 ]; do
  echo $i
  i=$((i + 1))
done
