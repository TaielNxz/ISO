#!/bin/bash

# Obtiene la extensión del archivo
extension=$1

# Obtiene el nombre de usuario
username=$(whoami)

# Crea un archivo de salida
echo "Nombre de usuario | Cantidad de archivos" > reporte.txt

# Busca todos los archivos con la extensión especificada
archivos=$(find . -type f -name "*.$extension")

# Cuenta la cantidad de archivos para cada usuario
for archivo in $archivos; do
  # Obtiene el nombre de usuario del archivo
  usuario=$(stat -c "%u" $archivo)

  # Cuenta la cantidad de archivos para el usuario actual
  contador=$(find . -type f -name "*.$extension" -user $usuario | wc -l)

  # Agrega una nueva línea al archivo de salida
  echo "$usuario | $contador" >> reporte.txt
done
