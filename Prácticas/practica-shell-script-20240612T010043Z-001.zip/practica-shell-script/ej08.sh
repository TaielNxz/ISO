!#/bin/bash

# Estructura IF
read -p "Ingrese un numero: " numero

if [ $numero -gt 10 ]; then
    echo "El numero es mayor que 10"
else 
    echo "El numero es menor o igual que 10"
fi


# -----------------------------------------
# Estructura CASE
read -p "Ingrese una caracter: " $caracter
case $caracter in
	[a-z]) echo "Es una minuscula";;
	[A-Z]) echo "Es una mayuscula";;
	[0-9]) echo "ES un nro";;
	*) echo "Es cualquier cosa"
esac

# -----------------------------------------
# WHILE
i=1

while [ $i -le 10 ] do
    echo $i
    i=$((i + 1))
done


# -----------------------------------------
# FOR
for i in {1..10} do
    echo $i
done

for i in 1 2 3 4 5 do
    echo $i
done

for ((i=1; i<=5; i++)) do
    echo $i
done


# ----------------------------------------
# SELECT
select opcion in "opcion1" " opcion2"; 
do
    case $opcion in
	"opcion1") echo "Es la opcion1";;
	"opcion2") echo "Es la opcion2";;
    esac
done
